# kubens

> Utility to switch between Kubernetes namespaces.

- List the namespaces:

`kubens`

- Change the active namespace:

`kubens {{name}}`

- Switch to the previous namespace:

`kubens -`
