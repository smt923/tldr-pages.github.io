# mkfifo

> Makes FIFOs (named pipes).

- Create a named pipe at a given path:

`mkfifo {{path/to/pipe}}`
