# wuzz

> Tool to interactively inspect HTTP requests and responses.

- Start wuzz:

`wuzz`

- Display help information:

`F1`

- Send an HTTP request:

`Ctrl + R`

- Switch to the next view:

`Ctrl + J, Tab`

- Switch to the previous view:

`Ctrl + K, Shift + Tab`
