# fc-list

> List available fonts installed on the system.

- Return a list of installed fonts with given name:

`fc-list | grep '{{DejaVu Serif}}'`
