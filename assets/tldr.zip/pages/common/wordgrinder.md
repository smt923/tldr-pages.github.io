# wordgrinder

> Command-line word processor.

- Start wordgrinder (loads a blank document by default):

`wordgrinder`

- Open a given file:

`wordgrinder {{filename}}`

- Show the menu:

`Alt + M`
