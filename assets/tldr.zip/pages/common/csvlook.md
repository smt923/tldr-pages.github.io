# csvlook

> Render a CSV file in the console as a fixed-width table.
> Included in csvkit.

- View a CSV file:

`csvlook {{data.csv}}`
