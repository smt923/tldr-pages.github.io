# git status

> Show the index (changed files).
> Homepage: <https://git-scm.com/docs/git-status>.

- Show changed files which are not yet added for commit:

`git status`

- Give output in short format:

`git status -s`
