# hg branch

> Create or show a branch name.

- Show the name of the currently active branch:

`hg branch`

- Create a new branch for the next commit:

`hg branch {{branch_name}}`
