# hangups 

> Third party command line client for Google Hangouts.

- Start hangups:

`hangups`

- View troubeshooting information and help:

`hangups -h`

- Set a refresh token for hangups:

`hangups --token-path {{/path/to/token}}`
