# hostnamectl

> Get or set the hostname of the computer.

- Get the hostname of the computer:

`hostnamectl`

- Set the hostname of the computer:

`sudo hostnamectl set-hostname "{{some_hostname}}"`
