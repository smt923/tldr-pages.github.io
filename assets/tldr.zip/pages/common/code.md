# code

> Visual Studio Code.
> Homepage: <https://github.com/microsoft/vscode>.

- Open VS Code:

`code`

- Open the current directory in VS Code:

`code .`

- Open a file or directory in VS Code:

`code {{path/to/file_or_directory}}`

- Open a file or directory in the currently open VS Code window:

`code --reuse-window {{path/to/file_or_directory}}`

- Compare two files in VS Code:

`code -d {{file1}} {{file2}}`
