# r

> R language interpreter.

- Start an R interactive shell (REPL):

`R`

- Check R version:

`R --version`

- Execute a file:

`R -f {{file.R}}`
