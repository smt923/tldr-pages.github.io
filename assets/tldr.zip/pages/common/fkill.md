# fkill

> Fabulously kill processes. Cross-platform.

- Run without arguments to use the interactive interface:

`fkill`

- Kill the process by pid, name or port:

`fkill {{pid|name|:port}}`
