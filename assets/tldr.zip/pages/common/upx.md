# upx

> Compress or decompress executables.

- Compress executable:

`upx {{file}}`

- Decompress executable:

`upx -d {{file}}`

- Detailed help:

`upx --help`
