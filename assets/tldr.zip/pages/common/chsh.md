# chsh

> Change user's login shell.

- List all installed shells:

`chsh -l`

- Change shell:

`chsh -s {{path/to/shell_binary}} {{username}}`
