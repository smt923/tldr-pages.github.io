# git merge

> Merge branches.

- Merge a branch with your current branch:

`git merge {{branch_name}}`

- Edit the merge message:

`git merge -e {{branch_name}}`
