# svgcleaner

> SVG image optimizing utility.

- Optimize an SVG image:

`svgcleaner {{input.svg}} {{output.svg}}`

- Optimize an SVG image multiple times:

`svgcleaner --multipass {{input.svg}} {{output.svg}}`
