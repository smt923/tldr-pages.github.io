# clear

> Clears the screen of the terminal.

- Clear the screen (equivalent to typing Control-L when using the bash shell):

`clear`
