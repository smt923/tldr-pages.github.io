# is-up

> Check whether a website is up or down.
> Homepage: <https://github.com/sindresorhus/is-up-cli>.

- Check the status of the specified website:

`is-up {{example.com}}`
