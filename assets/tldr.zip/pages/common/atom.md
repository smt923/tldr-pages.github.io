# atom

> A cross-platform pluggable text editor.
> Plugins are managed by `apm`.

- Open a file or folder:

`atom {{path/to/file_or_folder}}`

- Open a file or folder in a new window:

`atom -n {{path/to/file_or_folder}}`
