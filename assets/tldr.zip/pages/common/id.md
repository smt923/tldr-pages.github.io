# id

> Display current user and group identity.

- Display the current user identity as a number:

`id -u`

- Display the current group identity as a number:

`id -g`
