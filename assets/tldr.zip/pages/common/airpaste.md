# airpaste

> Share messages and files on the same network.

- Send file:

`airpaste < {{file.txt}}`

- Receive file:

`airpaste > {{file.txt}}`

- Create/Join channel:

`airpaste {{channel_name}}`
