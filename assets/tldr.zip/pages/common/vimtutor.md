# vimtutor

> Vim tutor, teaching the basic vim commands.

- Launch the vim tutor using the given language (en, fr, de, ...):

`vimtutor {{language}}`

- Exit the tutor:

`<Esc> :q <Enter>`
