# readlink

> Follow symlinks and get symlink information.

- Get the actual file to which the symlink points:

`readlink {{filename}}`

- Get the absolute path to a file:

`readlink -f {{filename}}`
